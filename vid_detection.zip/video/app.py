from flask import Flask, request, jsonify, render_template
import cv2
import os
from time import time
from ultralytics import YOLO
from werkzeug.utils import secure_filename

app = Flask(__name__)

app.config['MODEL_PATH'] = "static/best.pt"
app.config['UPLOAD_FOLDER'] = "static/uploads"
app.config['MAX_CONTENT_LENGTH'] = 20 * 1024 * 1024  # Set maximum video size to 20 MB
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mkv'}  # Add more video extensions if needed

model = YOLO(app.config['MODEL_PATH'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def detect_cigarette_in_video(video_path):
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return "Error opening video file"

    frame_count = 0
    results = []

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        start_time = time()
        pred = model(frame)
        end_time = time()

        processing_time = end_time - start_time

        # Process detection results
        curr_cigarette_count = pred[0].boxes.cls.shape[0]
        frame_count += 1

        if curr_cigarette_count > 0:
            result_str = f"{curr_cigarette_count} cigarettes detected in frame {frame_count}. Processing time: {processing_time:.2f} seconds"
            results.append(result_str)

    cap.release()

    if not results:
        results.append("No cigarette detected")

    return results

@app.route('/')
def display_landing_page():
    return render_template("index.html")

@app.route('/upload', methods=['POST'])
def classify_video():
    if 'video' not in request.files:
        return jsonify({'resText': 'Error uploading video'}), 400

    file = request.files['video']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'resText': 'Invalid file format'}), 400

    filename = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
    file.save(filename)

    results = detect_cigarette_in_video(filename)

    return jsonify({'resText': results}), 200

if __name__ == "__main__":
    app.run(port=5000)
