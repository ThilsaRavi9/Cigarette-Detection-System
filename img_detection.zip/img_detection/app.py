
from flask import Flask, request, jsonify, render_template
import cv2
import os
from ultralytics import YOLO
from werkzeug.utils import secure_filename

app = Flask(__name__)

app.config['MODEL_PATH'] = "static/best.pt"
app.config['UPLOAD_FOLDER'] = "static/uploads"
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

model = YOLO(app.config['MODEL_PATH'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def detect_cigarette(image_path):
    img = cv2.imread(image_path)
    pred = model(img)
    if pred[0].boxes.cls.shape[0] > 0:
        return f"{pred[0].boxes.cls.shape[0]} cigarettes detected!"
    else:
        return "No cigarette detected."

@app.route('/')
def display_landing_page():
    return render_template("index.html")

@app.route('/upload', methods=['POST'])
def classify_image():
    if 'image' not in request.files:
        return jsonify({'resText': 'Error uploading image'}), 400

    file = request.files['image']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'resText': 'Invalid file format'}), 400

    filename = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
    file.save(filename)

    result = detect_cigarette(filename)

    return jsonify({'resText': result}), 200

if __name__ == "__main__":
    app.run(port=5000)
